# Navigator Agent

navigates (name only)

Planet: Engine
Status: AWAKE
