# Phase 1: Spark

Spark phase

Planet: Engine
Status: AWAKE
