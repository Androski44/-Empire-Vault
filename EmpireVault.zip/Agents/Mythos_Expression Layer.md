# Expression Layer

turns inner work into outward expression

Planet: Mythos
Status: AWAKE
