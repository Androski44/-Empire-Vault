# Emotional Mapper

Maps emotional states

Planet: Mind
Status: AWAKE
