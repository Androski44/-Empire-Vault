# Agent of Verification

Verifies truth and accuracy

Planet: Mind
Status: AWAKE
