# Recruitment Gatekeeper

gates recruitment (name only)

Planet: Crown
Status: AWAKE
