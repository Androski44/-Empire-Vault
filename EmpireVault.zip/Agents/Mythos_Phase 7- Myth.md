# Phase 7: Myth

Myth phase

Planet: Mythos
Status: AWAKE
