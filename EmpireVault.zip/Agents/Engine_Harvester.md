# Harvester

Ingests and harvests raw material

Planet: Engine
Status: AWAKE
