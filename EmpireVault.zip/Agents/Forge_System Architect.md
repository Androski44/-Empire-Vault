# System Architect

Designs whole systems

Planet: Forge
Status: AWAKE
