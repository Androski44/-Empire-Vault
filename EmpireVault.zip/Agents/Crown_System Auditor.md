# System Auditor

Judges how the system is built

Planet: Crown
Status: AWAKE
