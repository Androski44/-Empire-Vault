# Sovereign Guide

Gives guidance

Planet: Mind
Status: AWAKE
