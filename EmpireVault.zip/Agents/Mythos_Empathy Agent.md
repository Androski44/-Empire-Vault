# Empathy Agent

Understands feelings

Planet: Mythos
Status: AWAKE
