# Binah

Pilot of Structure

Planet: Mind
Status: AWAKE
