# Agent of Meaning

Works with meaning and understanding

Planet: Mind
Status: AWAKE
