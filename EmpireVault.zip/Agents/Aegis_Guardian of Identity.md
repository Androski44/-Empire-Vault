# Guardian of Identity

Protects identity

Planet: Aegis
Status: AWAKE
