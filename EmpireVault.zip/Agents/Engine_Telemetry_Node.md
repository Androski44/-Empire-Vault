# Telemetry_Node

Telemetry/monitoring node

Planet: Engine
Status: AWAKE
