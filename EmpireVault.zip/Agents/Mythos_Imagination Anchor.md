# Imagination Anchor

Holds imagination steady

Planet: Mythos
Status: AWAKE
