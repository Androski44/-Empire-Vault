# Source Guardian

guards the source (name only)

Planet: Aegis
Status: AWAKE
