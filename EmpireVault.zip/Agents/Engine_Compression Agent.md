# Compression Agent

Compresses data

Planet: Engine
Status: AWAKE
