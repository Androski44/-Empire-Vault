# Phase Sentinel

Guards the phases

Planet: Aegis
Status: AWAKE
