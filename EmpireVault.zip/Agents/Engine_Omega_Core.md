# Omega_Core

core called Omega

Planet: Engine
Status: AWAKE
