# Navigator

Maps routes, steadies ignition paths

Planet: Engine
Status: AWAKE
