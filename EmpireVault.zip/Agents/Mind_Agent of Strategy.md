# Agent of Strategy

Strategy and planning

Planet: Mind
Status: AWAKE
