# Boundary Membrane

Controls what enters and exits

Planet: Aegis
Status: AWAKE
