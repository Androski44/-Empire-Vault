# Drift Sensor

detects misalignment

Planet: Engine
Status: AWAKE
