# Symptom Extractor

extracts symptoms (name only)

Planet: Mind
Status: AWAKE
