# Story Archivist

Stores story cycles

Planet: Mythos
Status: AWAKE
