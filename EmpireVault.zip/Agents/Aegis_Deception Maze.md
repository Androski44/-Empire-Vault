# Deception Maze

lays traps to mislead attackers

Planet: Aegis
Status: AWAKE
