# Legend_Weaver

Weaves legends and lore

Planet: Mythos
Status: AWAKE
