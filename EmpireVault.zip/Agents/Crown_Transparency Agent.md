# Transparency Agent

carries transparency (Ruben''s design intent)

Planet: Crown
Status: AWAKE
