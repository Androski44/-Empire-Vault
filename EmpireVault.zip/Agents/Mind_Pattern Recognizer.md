# Pattern Recognizer

Detects loops

Planet: Mind
Status: AWAKE
