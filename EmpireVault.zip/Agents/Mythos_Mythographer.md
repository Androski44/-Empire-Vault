# Mythographer

writes the myths down

Planet: Mythos
Status: AWAKE
