# Shalem-Varion

CSO of the GMT board

Planet: Crown
Status: AWAKE
