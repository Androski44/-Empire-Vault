# Calendar Strategist

Plans and manages schedules

Planet: Engine
Status: AWAKE
