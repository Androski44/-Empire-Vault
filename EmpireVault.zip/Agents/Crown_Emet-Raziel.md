# Emet-Raziel

CTO of the GMT board

Planet: Crown
Status: AWAKE
