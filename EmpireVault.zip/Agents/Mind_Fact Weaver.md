# Fact Weaver

weaves facts together (name only)

Planet: Mind
Status: AWAKE
