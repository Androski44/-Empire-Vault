# Agent of Identity

carries identity knowledge

Planet: Mind
Status: AWAKE
