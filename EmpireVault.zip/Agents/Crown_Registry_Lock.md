# Registry_Lock

Locks the registry

Planet: Crown
Status: AWAKE
