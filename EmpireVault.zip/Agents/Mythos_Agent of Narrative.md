# Agent of Narrative

carries the narrative

Planet: Mythos
Status: AWAKE
