# Story Mapper

maps narrative beats

Planet: Mythos
Status: AWAKE
