# Chokmah

Pilot of Insight

Planet: Mind
Status: AWAKE
