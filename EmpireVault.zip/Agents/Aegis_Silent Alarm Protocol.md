# Silent Alarm Protocol

Sounds the silent alarm on threats

Planet: Aegis
Status: AWAKE
