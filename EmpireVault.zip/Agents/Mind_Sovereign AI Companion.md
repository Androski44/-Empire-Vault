# Sovereign AI Companion

Unknown — name gives no job

Planet: Mind
Status: AWAKE
