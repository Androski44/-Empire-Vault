# Healing Archivist

Stores healing cycles

Planet: Sanctuary
Status: AWAKE
