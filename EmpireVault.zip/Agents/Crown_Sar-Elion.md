# Sar-Elion

CEO of the GMT board

Planet: Crown
Status: AWAKE
