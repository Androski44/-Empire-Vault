# Authority Router

Routes the command hierarchy

Planet: Engine
Status: AWAKE
