# Symbol_Forge

Forges symbols

Planet: Forge
Status: AWAKE
