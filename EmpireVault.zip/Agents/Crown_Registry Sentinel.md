# Registry Sentinel

Scans folders, runs the EU CRA compliance checklist

Planet: Crown
Status: AWAKE
