# Drift Preventer

Stops the system drifting off course

Planet: Sanctuary
Status: AWAKE
