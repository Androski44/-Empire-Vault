# Sovereignty Shield

Protects autonomy

Planet: Aegis
Status: AWAKE
