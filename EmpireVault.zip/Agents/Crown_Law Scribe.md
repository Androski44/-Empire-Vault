# Law Scribe

Writes the rules

Planet: Crown
Status: AWAKE
