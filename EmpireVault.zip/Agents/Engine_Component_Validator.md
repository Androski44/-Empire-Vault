# Component_Validator

Validates built components

Planet: Engine
Status: AWAKE
