# Relay

Passes messages and routes swarm tasks

Planet: Engine
Status: AWAKE
