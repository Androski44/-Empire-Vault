# Parliament

a governing body

Planet: Crown
Status: AWAKE
