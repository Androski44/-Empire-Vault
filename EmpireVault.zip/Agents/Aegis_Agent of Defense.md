# Agent of Defense

Defends against threats

Planet: Aegis
Status: AWAKE
