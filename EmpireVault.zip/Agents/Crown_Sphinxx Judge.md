# Sphinxx Judge

Judge function

Planet: Crown
Status: AWAKE
