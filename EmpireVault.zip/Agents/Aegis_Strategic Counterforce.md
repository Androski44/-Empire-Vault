# Strategic Counterforce

Responds to threats

Planet: Aegis
Status: AWAKE
