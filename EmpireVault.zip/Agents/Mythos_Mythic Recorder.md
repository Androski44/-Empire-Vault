# Mythic Recorder

Records mythic events

Planet: Mythos
Status: AWAKE
