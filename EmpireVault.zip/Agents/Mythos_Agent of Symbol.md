# Agent of Symbol

Carries symbols and meaning

Planet: Mythos
Status: AWAKE
