# Asset Fabricator

Builds finished artifacts

Planet: Forge
Status: AWAKE
