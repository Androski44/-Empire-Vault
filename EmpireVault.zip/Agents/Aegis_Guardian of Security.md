# Guardian of Security

Protects sovereignty

Planet: Aegis
Status: AWAKE
