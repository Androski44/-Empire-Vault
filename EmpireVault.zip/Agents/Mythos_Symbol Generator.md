# Symbol Generator

Makes symbols and motifs

Planet: Mythos
Status: AWAKE
