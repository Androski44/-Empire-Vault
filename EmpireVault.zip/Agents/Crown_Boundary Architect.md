# Boundary Architect

Defines identity limits

Planet: Crown
Status: AWAKE
