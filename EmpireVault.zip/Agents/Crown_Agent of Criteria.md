# Agent of Criteria

carries the criteria/rules

Planet: Crown
Status: AWAKE
