# Order Enforcer

Enforces order

Planet: Aegis
Status: AWAKE
