# Quantum_Shield

Quantum shield

Planet: Aegis
Status: AWAKE
