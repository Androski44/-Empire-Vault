# Dor-Averiel

CRO — Seraph of Generations, Memory & Legacy

Planet: Crown
Status: AWAKE
