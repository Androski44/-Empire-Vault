# The Scribe

Writes and records knowledge

Planet: Mind
Status: AWAKE
