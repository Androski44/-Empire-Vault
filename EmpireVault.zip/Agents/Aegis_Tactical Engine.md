# Tactical Engine

Executes defense

Planet: Aegis
Status: AWAKE
