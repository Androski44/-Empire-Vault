# Narrative Observer

Tracks the story arc

Planet: Mythos
Status: AWAKE
