# Emotion_Core

Emotion core

Planet: Mythos
Status: AWAKE
